# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(retry-matrix src/retry-matrix.cpp)
set_property(TARGET retry-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(retry-matrix lionss pthread)

add_executable(maximal-versions src/maximal-versions.cpp)
set_property(TARGET maximal-versions PROPERTY CXX_STANDARD 11)
target_link_libraries(maximal-versions lionss pthread)

add_executable(hardening-check src/hardening-check.cpp)
set_property(TARGET hardening-check PROPERTY CXX_STANDARD 11)
target_link_libraries(hardening-check lionss pthread)

add_executable(draft-release src/draft-release.cpp)
set_property(TARGET draft-release PROPERTY CXX_STANDARD 11)
target_link_libraries(draft-release lionss pthread)

add_executable(encoding-tests src/encoding-tests.cpp)
set_property(TARGET encoding-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(encoding-tests lionss pthread)

add_executable(p99-latency src/p99-latency.cpp)
set_property(TARGET p99-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(p99-latency lionss pthread)

add_executable(live-tests src/live-tests.cpp)
set_property(TARGET live-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(live-tests lionss pthread)

add_executable(upgrade-tests src/upgrade-tests.cpp)
set_property(TARGET upgrade-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(upgrade-tests lionss pthread)

add_executable(soname-check src/soname-check.cpp)
set_property(TARGET soname-check PROPERTY CXX_STANDARD 11)
target_link_libraries(soname-check lionss pthread)

add_executable(meson-build src/meson-build.cpp)
set_property(TARGET meson-build PROPERTY CXX_STANDARD 11)
target_link_libraries(meson-build lionss pthread)

add_executable(ipc-bench src/ipc-bench.cpp)
set_property(TARGET ipc-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(ipc-bench lionss pthread)

add_executable(codeql src/codeql.cpp)
set_property(TARGET codeql PROPERTY CXX_STANDARD 11)
target_link_libraries(codeql lionss pthread)

add_executable(valgrind-drd src/valgrind-drd.cpp)
set_property(TARGET valgrind-drd PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-drd lionss pthread)

add_executable(watchos-build src/watchos-build.cpp)
set_property(TARGET watchos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(watchos-build lionss pthread)

add_executable(tag-validation src/tag-validation.cpp)
set_property(TARGET tag-validation PROPERTY CXX_STANDARD 11)
target_link_libraries(tag-validation lionss pthread)

add_executable(mutation-testing src/mutation-testing.cpp)
set_property(TARGET mutation-testing PROPERTY CXX_STANDARD 11)
target_link_libraries(mutation-testing lionss pthread)

add_executable(headless-tests src/headless-tests.cpp)
set_property(TARGET headless-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(headless-tests lionss pthread)

add_executable(boundary-tests src/boundary-tests.cpp)
set_property(TARGET boundary-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(boundary-tests lionss pthread)

add_executable(cmake-presets src/cmake-presets.cpp)
set_property(TARGET cmake-presets PROPERTY CXX_STANDARD 11)
target_link_libraries(cmake-presets lionss pthread)

add_executable(contract-tests src/contract-tests.cpp)
set_property(TARGET contract-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(contract-tests lionss pthread)

add_executable(rpath-check src/rpath-check.cpp)
set_property(TARGET rpath-check PROPERTY CXX_STANDARD 11)
target_link_libraries(rpath-check lionss pthread)

add_executable(afl-fuzz src/afl-fuzz.cpp)
set_property(TARGET afl-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(afl-fuzz lionss pthread)

add_executable(package-snap src/package-snap.cpp)
set_property(TARGET package-snap PROPERTY CXX_STANDARD 11)
target_link_libraries(package-snap lionss pthread)

add_executable(export-map-check src/export-map-check.cpp)
set_property(TARGET export-map-check PROPERTY CXX_STANDARD 11)
target_link_libraries(export-map-check lionss pthread)

add_executable(unicode-tests src/unicode-tests.cpp)
set_property(TARGET unicode-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(unicode-tests lionss pthread)

add_executable(linux-armv7 src/linux-armv7.cpp)
set_property(TARGET linux-armv7 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armv7 lionss pthread)

add_executable(reproducible-build src/reproducible-build.cpp)
set_property(TARGET reproducible-build PROPERTY CXX_STANDARD 11)
target_link_libraries(reproducible-build lionss pthread)

add_executable(function-coverage src/function-coverage.cpp)
set_property(TARGET function-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(function-coverage lionss pthread)

add_executable(duplication-check src/duplication-check.cpp)
set_property(TARGET duplication-check PROPERTY CXX_STANDARD 11)
target_link_libraries(duplication-check lionss pthread)

add_executable(nix-build src/nix-build.cpp)
set_property(TARGET nix-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nix-build lionss pthread)

