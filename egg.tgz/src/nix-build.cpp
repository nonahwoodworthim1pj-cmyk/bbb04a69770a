// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("nix build"); }
int main(){
  announce();
  return lionss_run_workload("nix-build");
}
