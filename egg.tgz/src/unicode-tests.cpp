// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("unicode tests\n", stdout);
  return lionss_run_workload("unicode-tests");
}
