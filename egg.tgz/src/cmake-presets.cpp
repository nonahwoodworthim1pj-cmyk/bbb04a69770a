// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cmake presets\n", stdout);
  return lionss_run_workload("cmake-presets");
}
