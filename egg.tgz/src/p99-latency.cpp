// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("p99 latency"); }
int main(){
  announce();
  return lionss_run_workload("p99-latency");
}
